"""Turn a saved AI-radar snapshot into an offline verification worksheet.

Python 3.10+, standard library only. No network, account access or publication.
"""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
from html import escape
import json
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit


def build(snapshot, output):
    raw = snapshot.read_bytes()
    data = json.loads(raw)
    if not isinstance(data.get('candidates'), list):
        raise ValueError('Expected a saved snapshot with a candidates list')
    rows, seen = [], set()
    for item in data['candidates'][:100]:
        try:
            url = urlsplit(item.get('url') or '')
            if url.scheme != 'https' or not url.hostname or url.username or url.password:
                continue
            link = urlunsplit((url.scheme, url.netloc.lower(), url.path, url.query, ''))
        except ValueError:
            continue
        if link in seen:
            continue
        seen.add(link)
        rows.append({
            'id': 'lead-' + hashlib.sha256(link.encode()).hexdigest()[:20],
            'title': str(item.get('title_from_upstream') or '')[:600],
            'url': link,
            'feed_generated_at': item.get('feed_generated_at'),
            'problem_draft': item.get('problem_draft'),
            'evidence_status': '待核验原始来源',
            'publication_ready': False,
        })
    output.mkdir(parents=True, exist_ok=True)
    report = {
        'built_at': datetime.now(timezone.utc).isoformat(),
        'snapshot_checked_at': data.get('checked_at'),
        'input_sha256': hashlib.sha256(raw).hexdigest(),
        'candidate_count': len(rows), 'publication_ready_count': 0,
        'coverage': '保存快照中的公开候选；不是当前全网资讯',
        'candidates': rows,
    }
    (output / 'result.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    columns = ['id', 'title', 'url', 'feed_generated_at', 'problem_draft', 'evidence_status', 'publication_ready']
    with (output / 'candidates.csv').open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            # Keep spreadsheet applications from interpreting upstream titles as formulas.
            writer.writerow({k: ("'" + v if isinstance(v, str) and v.startswith(('=', '+', '-', '@')) else v) for k, v in row.items()})
    template = '''# Charlii 选题任务卡

系列与期号：
读者在做什么，卡在哪一步：
看完能拿走的产物或判断：
输入、环境、费用与权限：
原始来源、原始发布日期、实际读取范围：
步骤与结果核对方法：
两张不同真实项目截图、图注和来源：
能直接复制的材料：
未实测或尚待确认的部分：
相对上期新增的步骤、图、案例或答案：
本期适合的两到三种形式与平台：
下一步：先链接一份已经存在的相关材料；后续题未完成时不承诺已可领取。

AI博士Charlii / CharliiAI · charliiai.com
'''
    (output / 'task-card.md').write_text(template, encoding='utf-8')
    e = lambda value: escape(str(value or ''))
    table = ''.join('<tr><td>' + e(r['title']) + '</td><td><a href="' + e(r['url']) + '">原始链接</a></td><td>' + e(r['problem_draft'] or '先判断与读者任务的关系') + '</td><td>待核验</td></tr>' for r in rows)
    page = '''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Charlii · AI线索核验工作台</title><style>
*{box-sizing:border-box}body{margin:0;background:#f1f5f3;color:#173a35;font:16px/1.8 "Microsoft YaHei",sans-serif}main{max-width:1080px;margin:auto;padding:30px 18px}header,section{background:white;border:1px solid #d5e2dc;border-radius:18px;padding:25px;margin-bottom:20px}h1{font-size:30px;line-height:1.4}h2{font-size:23px}.stats{display:flex;gap:16px;flex-wrap:wrap}.stats div{padding:12px 20px;background:#e9f4ee;border-radius:12px}.stats b{font-size:32px;display:block}p,li{overflow-wrap:anywhere}a{color:#087867}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#eef4f0;padding:18px;border-radius:10px}table{border-collapse:collapse;width:100%;font-size:14px}td,th{padding:12px;text-align:left;border-bottom:1px solid #dde5e0;vertical-align:top}td:first-child{width:42%}.table{overflow:auto}code{overflow-wrap:anywhere}small{color:#566a62}@media(max-width:600px){h1{font-size:25px}header,section{padding:20px 16px}.table table{min-width:660px}}
</style></head><body><main><header><small>AI博士Charlii / CharliiAI · charliiai.com · 工作流实验 001</small><h1>AI资讯太多，先把线索变成可核查清单</h1><p>把一份保存的公开快照导出成 CSV、JSON 和空白选题任务卡，保留每条来源与证据状态。此工具处理本地文件，不替你确认原文事实。</p><div class="stats"><div><b>COUNT</b>条独立URL</div><div><b>0</b>条已具备发布条件</div><div><b>3</b>种可复用输出</div></div><p>输入快照采集时间：STAMP</p><a href="candidates.csv" download>下载候选CSV</a> · <a href="task-card.md" download>下载选题任务卡</a> · <a href="result.json" download>下载结果JSON</a></header>
<section id="method"><h2>照着跑：离线导出与结果核对</h2><ol><li>准备 Python 3.10 或更新版本，无须安装第三方包。</li><li>将 radar_to_tasks.py 和 sample.json 放在同一目录。</li><li>执行下面命令，再打开 result/index.html。</li><li>核对输出行数、来源URL、快照时间与未核验状态；过期快照不能作为今日新闻。</li><li>选一个与读者任务有关的题，回原文核对，再填写任务卡。</li></ol><pre>python radar_to_tasks.py sample.json --output result</pre><p>输入指纹：<code>HASH</code></p><p>常见失败：输入需要 candidates 列表；重复URL只留一条；非HTTPS和含账号口令的URL会跳过。脚本未执行网络访问或自动选入生产。</p></section>
<section id="candidates"><h2>实际输出：逐条保留来源与待核验状态</h2><p>标题及问题草案来自输入快照。聚合标题只是线索，问题草案只是编辑提示。</p><div class="table"><table><thead><tr><th>上游标题</th><th>来源</th><th>问题草案</th><th>证据状态</th></tr></thead><tbody>ROWS</tbody></table></div></section>
<section><h2>带走材料之后，下一步做什么？</h2><p>用任务卡选一个具体问题，把原文、截图、操作与结果补齐。下一次同系列要新增一个真实案例或失败处理步骤，避免重复介绍同一段演示。</p><p>数据来源：<a href="https://github.com/LearnPrompt/ai-news-radar">AI News Radar官方仓库公开数据</a>。来源核验和本机工具实测分别记录。</p></section></main></body></html>'''
    page = page.replace('COUNT', str(len(rows))).replace('STAMP', e(report['snapshot_checked_at'])).replace('HASH', report['input_sha256']).replace('ROWS', table)
    (output / 'index.html').write_text(page, encoding='utf-8')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('snapshot', type=Path)
    parser.add_argument('--output', type=Path, default=Path('result'))
    args = parser.parse_args()
    result = build(args.snapshot, args.output)
    print(json.dumps({k: result[k] for k in ['snapshot_checked_at', 'input_sha256', 'candidate_count', 'publication_ready_count']}, ensure_ascii=False))
