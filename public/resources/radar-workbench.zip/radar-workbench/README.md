# AI资讯太多，先做一份可核查清单

AI博士Charlii · Charlii工作流实验 001 · charliiai.com

这个案例使用一份真实保存的公开雷达快照，导出候选 CSV、结果 JSON 和空白选题任务卡。读者可以替换自己的快照重复运行。

## 环境与输入

Python 3.10+，只使用标准库。导出过程无需账号、API key、第三方依赖或网络。

`sample.json` 是 AI News Radar 公开候选的保存样本，原始采集时间为 2026-10-20T16:10:25.406026+00:00。它包含24条候选，不代表读者运行当天的热点。数据来源：

- https://raw.githubusercontent.com/LearnPrompt/ai-news-radar/master/data/daily-brief.json
- https://raw.githubusercontent.com/LearnPrompt/ai-news-radar/master/data/today-projects.json
- 上游项目：https://github.com/LearnPrompt/ai-news-radar

## 操作

1. 下载并解压整个资料包，进入 `radar-workbench` 目录。
2. 运行：`python radar_to_tasks.py sample.json --output result`。
3. 打开 `result/index.html` 查看工作台，或用表格软件打开 `result/candidates.csv`。
4. 对照 `result/result.json` 核验行数、来源URL、输入SHA256及可发布数量。
5. 挑一项与读者任务有关的线索，打开原始来源核对日期、正文和使用条件，再填写 `result/task-card.md`。

## 本次结果与核对

本地实际导出24条记录，精确URL无重复；CSV与JSON条数一致，全部为“待核验原始来源”，可发布数量为0。输入指纹保存在结果中。这个结果证明本地导出可以运行；候选所指产品的功能、性能和使用效果要另外核查。

工作台的两张截图记录真实运行后的不同区域：步骤与导出结果、候选来源与证据状态。截图不是上游项目的实测成绩。

## 常见失败

- 输入无 `candidates` 列表：先检查文件结构，脚本会报错退出。
- 重复URL：去除片段后只留一条；不同URL的同一事件仍需人工合并。
- 非HTTPS或URL含账号口令：不进入导出结果。
- 旧快照：按保存时间说明背景，不将其当成今日新闻。
- 标题没有关联到具体任务：先留候选，不用融资额、星数或热度代替读者价值。

下一步是“怎样从清单挑一个问题，补齐原文、截图和实际结果”。本包先交付已经可运行的导出与任务卡。
